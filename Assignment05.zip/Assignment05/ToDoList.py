# ------------------------------------------------#
# Title: ToDoList.py
# Desc: This program lets the user display, add, remove,
#       and save data to a text file. The code is broken
#       into 3 sections.  Data, Processing, and Input/Output.
# Change Log:
# Ryan Fear, 2021-11-12, Created File
# ------------------------------------------------#
from os import path

# -- Data -- #
# declare variables and constants
file_name = "ToDoList.txt"  # An object that represents a file
data_row = ""  # A row of text data from the file
data_dict = {}  # A row of data separated into elements of a dictionary {Task,Priority}
data_table = []  # A list that acts as a 'table' of rows
choice = ""  # A Capture the user option selection

# -- Processing -- #
# Step 1 - When the program starts, load the any data you have in a text file called ToDoList.txt
# Check if file exist. If it doesn't print message. If it does load data and store to variables.

file_exists = path.exists(file_name)
if file_exists == False:
    print(f"\n\tHello, the file '{file_name}' does not exist yet.")
    print("\tThe program compiles a list of tasks and their priority level.")
    print("\tThe rank for the priorities is [1-5]. [1] being highest and [5] being lowest.")
else:
    f = open(file_name, "r")
    print(f"\n\tHello, the file '{file_name}' exist. The contents have been loaded.")
    print("\tThe program compiles a list of tasks and their priority level.")
    print("\tThe rank for the priorities is [1-5]. [1] being highest and [5] being lowest.")
    for line in f:
        data_row = line.split(",")
        data_dict = {"task": data_row[0], "priority": data_row[1].rstrip("\n")}
        data_table.append(data_dict)
    f.close()

# -- Input/Output -- #
# Step 2 - Display a menu of choices to the user
while True:

    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)

    choice = str(input("Which option would you like to perform? [1 to 5] - "))

    # Step 3 - Show the current items in the table
    if choice.strip() == '1':
        count = len(data_table)
        print(f"\nThere are {count} task(s) in your list.")
        for item in data_table:
            print(f"Task: {item['task']}\t Priority: {item['priority']}")

    # Step 4 - Add a new item to the list/Table
    elif choice.strip() == '2':
        data_dict = {}  # set data_dict to a blank dictionary
        new_task = input("What is the new task you'd like to add: ")

        valid = ["1", "2", "3", "4", "5"]  # temporary list of valid inputs. Used in while loop.
        while True:
            new_priority = input("What is the priority level of this task? [1 (highest) - 5 (lowest)]: ")
            if new_priority in valid:
                break

        data_dict["task"] = new_task.capitalize()
        data_dict["priority"] = new_priority
        data_table.append(data_dict)  # Add new data to the data_table

    # Step 5 - Remove a new item from the list/Table
    elif choice.strip() == '3':
        print("Stored data: ")
        valid = []  # initialize a valid list
        for i in range(0, len(data_table)):
            print(f"Line [{i+1}]: {data_table[i]}")
            valid.append(i)

        while True:
            opt = input("\nWhich line would you like to remove? ")
            if int(opt) - 1 in valid:
                data_table.pop(int(opt)-1)
                break

        print("\nUpdated data: ")
        for i in range(0, len(data_table)):
            print(f"Line [{i+1}]: {data_table[i]}")

    # Step 6 - Save tasks to the ToDoList.txt file
    elif choice.strip() == '4':
        f = open(file_name, "w")

        for item in data_table:
            f.write(item['task'] + "," + item['priority'] + "\n")

        f.close()

        print(f"\nData printed to the file '{file_name}'.")

    # Step 7 - Exit program
    elif choice.strip() == '5':
        break  # and Exit the program
